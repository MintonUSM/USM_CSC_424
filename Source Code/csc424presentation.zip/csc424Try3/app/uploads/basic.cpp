#include <iostream>

int main()
{
	int a = 8;
	int b = 3;
	int c = 4;
	int answer = ((b*c)/c)+a;
    std::cout << answer << std::endl;
    return 0;
}